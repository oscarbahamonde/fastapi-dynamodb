import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='bluetabob',
    application_name='my-awesome-app',
    app_uid='5bG8FYvmKyK15MxtFs',
    org_uid='4f745933-3227-46a9-b308-92af7612ef16',
    deployment_uid='02395f20-0dac-407d-935c-aaa06e90e6c3',
    service_name='my-awesome-app',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='staging',
    plugin_version='6.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'my-awesome-app-staging-app', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('main.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
